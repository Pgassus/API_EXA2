import { config } from "dotenv";
config();

export const BD_HOST = process.env.BD_HOST || "127.0.0.1";
export const BD_DATABASE = process.env.BD_DATABASE || 'examenrifas';
export const DB_USER = process.env.DB_USER || "root";
export const DB_PASSWORD = process.env.DB_PASSWORD || "";
export const DB_PORT = process.env.DB_PORT || 3306;
export const PORT = process.env.PORT || 3000;
