import { conmysql } from "../db.js";

// Listar todos los equipos
export const listarEquipos = async (req, res) => {
  try {
    const [result] = await conmysql.query("SELECT * FROM equipo;");
    res.json({
      Mensaje:
        result.length > 0
          ? "Operación Exitosa"
          : "No hay registros para la consulta",
      cantidad: result.length,
      data: result,
      color: result.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Buscar equipos por id
export const buscarEquipos  = async (req, res) => {
  try {
    const { id } = req.params; // Obtener el ID desde los parámetros de la URL
    const [result] = await conmysql.query(
      `SELECT id_eq, nombre_eq FROM equipo WHERE id_eq = ?`,
      [id] // Pasar el ID como parámetro directamente
    );

    res.json({
      Mensaje:
        result.length > 0
          ? "Equipo encontrado"
          : "No se encontró un equipo con ese ID",
      data: result.length > 0 ? result[0] : null, // Devolver el primer resultado o null
      color: result.length > 0 ? "success" : "warning",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

export const peq = async (req, res) => {
  try {
    const [result] = await conmysql.query(`
      SELECT p.*, e1.nombre_eq AS eq_uno_nombre, e2.nombre_eq AS eq_dos_nombre
      FROM partido p
      JOIN equipo e1 ON p.eq_uno = e1.id_eq
      JOIN equipo e2 ON p.eq_dos = e2.id_eq;
    `);

    res.json({
      Mensaje: result.length > 0 ? "Operación Exitosa" : "No hay registros para la consulta",
      cantidad: result.length,
      data: result,
      color: result.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Insertar un nuevo equipo
export const insertarEquipo = async (req, res) => {
  try {
    const { nombre_eqq } = req.body;

    if (!nombre_eqq) {
      return res.status(400).json({ message: "El nombre del equipo es obligatorio" });
    }

    const [result] = await conmysql.query(
      `INSERT INTO equipo (nombre_eqq) VALUES (?)`,
      [nombre_eqq]
    );

    res.json({
      Mensaje: "Equipo registrado correctamente",
      color: "success",
      insertId: result.insertId,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};
