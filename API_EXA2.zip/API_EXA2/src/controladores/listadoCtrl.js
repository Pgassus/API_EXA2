import { conmysql } from "../db.js";

/*export const obtenerPronosticosAcertados = async (req, res) => {
  try {
    const query = `
      SELECT p.id_par, pr.id_usr, pr.id_res, pr.id_pron, p.eq_uno, p.eq_dos
      FROM pronostico pr
      JOIN partido p ON pr.id_par = p.id_par
      WHERE pr.id_res = p.id_res AND p.estado_par = 'cerrado';
    `;
    
    const [resultados] = await conmysql.query(query);
    
    if (resultados.length > 0) {
      // Si encontramos acertados, los devolvemos en formato adecuado
      res.json({ color: 'success', data: resultados });
    } else {
      res.json({ color: 'danger', mensaje: 'No hay pronósticos acertados.' });
    }
  } catch (error) {
    console.error('Error al obtener los pronósticos acertados:', error);
    res.status(500).json({ message: error.message });
  }
};*/
export const obtenerPronosticosAcertados = async (req, res) => {
  try {
    const query = `
    SELECT p.id_par, pr.id_usr, pr.id_res, pr.id_pron, pr.valor, p.estado_par, 
       e1.nombre_eq AS eq_uno_nombre, e2.nombre_eq AS eq_dos_nombre,
       r.descripcion_res, u.nombres, u.usuario
FROM pronostico pr
JOIN partido p ON pr.id_par = p.id_par
JOIN equipo e1 ON p.eq_uno = e1.id_eq
JOIN equipo e2 ON p.eq_dos = e2.id_eq
JOIN resultado r ON pr.id_res = r.id_res
JOIN usuario u ON pr.id_usr = u.id_usr
WHERE pr.id_res = p.id_res AND p.estado_par = 'cerrado';

    `;
    
    const [resultados] = await conmysql.query(query);
    
    if (resultados.length > 0) {
      res.json({ color: 'success', data: resultados });
    } else {
      res.json({ color: 'danger', mensaje: 'No hay pronósticos acertados.' });
    }
  } catch (error) {
    console.error('Error al obtener los pronósticos acertados:', error);
    res.status(500).json({ message: error.message });
  }
};



export const listaUsuario = async (req, res) => {
  try {
    const [result] = await conmysql.query("SELECT * FROM usuario;");
    res.json({
      Mensaje:
        result.length > 0
          ? "Operación Exitosa"
          : "No hay registros para la consulta",
      cantidad: result.length,
      data: result,
      color: result.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};
///////////////////////////////////////////////////////


// Definir la lista temporal para la recaudación
// Función para obtener los pronósticos y calcular la recaudación
// Función para obtener la recaudación
export const obtenerRecaudacion = async (req, res) => {
  try {
    // Consultar los valores de los pronósticos
    const [pronosticos] = await conmysql.query(`
      SELECT pr.valor 
      FROM pronostico pr
      JOIN partido p ON pr.id_par = p.id_par
      WHERE p.estado_par = 'cerrado';  
    `);

    // Si no hay pronósticos
    if (pronosticos.length === 0) {
      return res.status(404).json({ message: 'No hay pronósticos cerrados para sumar.' });
    }

    // Sumar todos los valores de los pronósticos
    const totalRecaudado = pronosticos.reduce((total, pronostico) => total + pronostico.valor, 0);

    // Devolver el total recaudado
    res.json({
      mensaje: 'Recaudación calculada con éxito',
      totalRecaudado: totalRecaudado
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

// Función para seleccionar al ganador
export const seleccionarGanador = async (req, res) => {
  try {
    // Obtener los usuarios que acertaron el pronóstico
    const [acertantes] = await conmysql.query(`
      SELECT pr.id_usr, u.usuario,u.nombres, u.cedula, u.direccion, u.telefono
      FROM pronostico pr
      JOIN partido p ON pr.id_par = p.id_par
      JOIN usuario u ON pr.id_usr = u.id_usr
      WHERE pr.id_res = p.id_res AND p.estado_par = 'cerrado';
    `);

    // Si no hay acertantes
    if (acertantes.length === 0) {
      return res.status(404).json({ message: 'No hay usuarios que acertaron el pronóstico.' });
    }

    // Selección aleatoria de un ganador basado en id_usr
    const ganador = acertantes[Math.floor(Math.random() * acertantes.length)];

    // Obtener el total recaudado
    const [recaudacion] = await conmysql.query(`
      SELECT SUM(pr.valor) AS totalRecaudado
      FROM pronostico pr
      JOIN partido p ON pr.id_par = p.id_par
      WHERE p.estado_par = 'cerrado';
    `);

    const totalRecaudado = recaudacion[0].totalRecaudado;

    // Calcular el premio (10% del total recaudado)
    const premio = totalRecaudado * 0.10;

    // Devolver el ganador y su premio
    res.json({
      mensaje: 'Ganador seleccionado correctamente',
      ganador: {
        nombre: ganador.nombres,
        Usuario:ganador.usuario,
        cedula: ganador.cedula,
        direccion: ganador.direccion,
        telefono: ganador.telefono,
        premio: premio
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};
