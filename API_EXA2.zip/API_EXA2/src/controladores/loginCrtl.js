/*import { conmysql } from "../db.js";

export const login = async (req, res) => {
  const { usuario, clave } = req.body;

  try {
    // Consulta para verificar credenciales
    const [result] = await conmysql.query(
      `SELECT * FROM usuario WHERE usuario = ? AND clave = ?`,
      [usuario, clave]
    );

    if (result.length > 0) {
      const usuarioData = result[0];

      // Enviar los datos del usuario como respuesta
      return res.json({
        Mensaje: "Inicio de sesión exitoso",
        color: "success",
        data: {
          id_usr: usuarioData.id, // ID del usuario
          usuario: usuarioData.usuario, // Nombre del usuario
          rol: usuarioData.per_id === 1 ? "admin" : "user" , // Rol basado en per_id
        },
      });
    } else {
      return res.status(401).json({
        Mensaje: "Usuario o clave incorrectos",
        color: "danger",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ Mensaje: "Error en el servidor", color: "danger" });
  }
};
*/
import { conmysql } from "../db.js";

export const login = async (req, res) => {
  const { usuario, clave } = req.body;

  try {
    // Consulta para verificar credenciales
    const [result] = await conmysql.query(
      `SELECT * FROM usuario WHERE usuario = ? AND clave = ?`,
      [usuario, clave]
    );

    if (result.length > 0) {
      const usuarioData = result[0];

      // Enviar los datos del usuario como respuesta
      return res.json({
        Mensaje: "Inicio de sesión exitoso",
        color: "success",
        data: {
          id_usr: usuarioData.id_usr, // ID del usuario (asegúrate que 'id' es el campo correcto)
          usuario: usuarioData.usuario, // Nombre del usuario
          rol: usuarioData.per_id === 1 ? "admin" : "user", // Rol basado en per_id
        },
      });
    } else {
      return res.status(401).json({
        Mensaje: "Usuario o clave incorrectos",
        color: "danger",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ Mensaje: "Error en el servidor", color: "danger" });
  }
};

