import { conmysql } from "../db.js";

/*export const listarpartido = async (req, res) => {
  try {
    const [result] = await conmysql.query("SELECT * FROM partido;");
    res.json({
      Mensaje:
        result.length > 0
          ? "Operación Exitosa"
          : "No hay registros para la consulta",
      cantidad: result.length,
      data: result,
      color: result.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  } 
};
*/

// Obtener todos los partidos con nombres de equipos y descripciones de resultados
export const listp = async (req, res) => {
   try {
     const query = `
       SELECT p.id_par, p.eq_uno, p.eq_dos, p.fecha_par, p.id_res, p.estado_par,
              eq1.nombre_eq AS eq_uno_nombre, eq2.nombre_eq AS eq_dos_nombre, r.descripcion_res
       FROM partido p
       JOIN equipo eq1 ON p.eq_uno = eq1.id_eq
       JOIN equipo eq2 ON p.eq_dos = eq2.id_eq
       LEFT JOIN resultado r ON p.id_res = r.id_res;
     `;
     const [result] = await conmysql.query(query);

     res.json({
       Mensaje: result.length > 0 ? "Operación Exitosa" : "No hay registros para la consulta",
       cantidad: result.length,
       data: result,
       color: result.length > 0 ? "success" : "danger",
     });
     
   } catch (error) {
     return res.status(500).json({ message: error.message });
   }
};

// listarpartido.js o el archivo correspondiente
export const listarpartido = async (req, res) => {
  try {
    const [result] = await conmysql.query(`
      SELECT 
        p.id_par, 
        e1.nombre_eq AS nombre_eq_uno, 
        e2.nombre_eq AS nombre_eq_dos, 
        p.fecha_par, 
        p.id_res, 
        p.estado_par,
        r.descripcion_res
      FROM 
        partido p
      JOIN 
        equipo e1 ON p.eq_uno = e1.id_eq
      JOIN 
        equipo e2 ON p.eq_dos = e2.id_eq
      JOIN
        resultado r ON p.id_res = r.id_res;
    `);

    res.json({
      Mensaje: result.length > 0 ? "Operación Exitosa" : "No hay registros para la consulta",
      cantidad: result.length,
      data: result, // Enviar los partidos con nombres de equipos y descripción del resultado
      color: result.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ message: error.message, color: "danger" });
  }
};



export const insertPartido = async (req, res) => {
  try {
    const { eq_uno, eq_dos, fecha_par, id_res, estado_par } = req.body;

    const [result] = await conmysql.query(
      `INSERT INTO partido (eq_uno, eq_dos, fecha_par, id_res, estado_par) VALUES (?, ?, ?, ?, ?)`,
      [eq_uno, eq_dos, fecha_par, id_res, estado_par]
    );

    res.json({
      Mensaje: "Partido registrado correctamente",
      color: "success",
      insertId: result.insertId, // ID del partido insertado
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};



//listar resulatdos

export const listarResultados = async (req, res) => {
  try {
    const [resultados] = await conmysql.query(`
      SELECT id_res, descripcion_res 
      FROM resultado 
    `);

    res.json({
      Mensaje: resultados.length > 0 ? "Operación Exitosa" : "No hay resultados disponibles",
      data: resultados, // Devuelve id_res y descripcion_res
      color: resultados.length > 0 ? "success" : "danger",
    });
  } catch (error) {
    return res.status(500).json({ Mensaje: "Error al listar resultados", error });
  }
};




// Controlador para actualizar el resultado del partido Y el estado
export const actualizarPartido = async (req, res) => {
  try {
    const { id_partido, id_res, estado_par } = req.body;

    // Validar que el id_res exista en la tabla resultado
    const validarResultado = `
      SELECT COUNT(*) as count
      FROM resultado
      WHERE id_res = ?
    `;
    const [validacion] = await conmysql.query(validarResultado, [id_res]);
    if (validacion[0].count === 0) {
      return res.status(400).json({
        Mensaje: "El id_res no existe en la tabla resultado.",
        color: "danger",
      });
    }

    // Actualizar el partido
    const query = `
      UPDATE partido
      SET id_res = ?, estado_par = ?
      WHERE id_par = ?
    `;
    const [result] = await conmysql.query(query, [id_res, estado_par, id_partido]);

    if (result.affectedRows > 0) {
      res.json({ Mensaje: "Partido actualizado correctamente", color: "success" });
    } else {
      res.status(404).json({ Mensaje: "Partido no encontrado", color: "danger" });
    }
  } catch (error) {
    console.error('Error en actualizarPartido:', error);
    return res.status(500).json({ message: error.message });
  }
};