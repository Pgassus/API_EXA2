import { conmysql } from "../db.js";
export const registrarPronostico = async (req, res) => {
  try {
    const { id_usr, id_par, id_res, valor } = req.body;

   
    // Realizar la inserción en la base de datos
    const [result] = await conmysql.query(
      `INSERT INTO pronostico (id_usr, id_par, id_res, valor, fecha_registro) VALUES (?, ?, ?, ?, NOW())`,
      [id_usr, id_par, id_res, valor]
    );

    return res.json({
      color: "success",
      mensaje: "Pronóstico registrado correctamente",
      insertId: result.insertId,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ color: "danger", mensaje: "Error al registrar el pronóstico." });
  }
};


export const obtenerPartidosActivos = async (req, res) => {
  try {
    const [partidosActivos] = await conmysql.query(
      `SELECT p.id_par, e1.nombre_eq AS equipo_uno, e2.nombre_eq AS equipo_dos, p.fecha_par, p.estado_par, r.descripcion_res 
       FROM partido p
       JOIN equipo e1 ON p.eq_uno = e1.id_eq
       JOIN equipo e2 ON p.eq_dos = e2.id_eq
       LEFT JOIN resultado r ON p.id_res = r.id_res
       WHERE p.estado_par = 'activo'`
    );

    if (partidosActivos.length > 0) {
      return res.json({
        color: "success",
        data: partidosActivos,
      });
    } else {
      return res.status(404).json({
        color: "danger",
        Mensaje: "No hay partidos activos.",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ color: "danger", Mensaje: "Error al obtener los partidos activos." });
  }
};
