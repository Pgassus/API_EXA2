import { Router } from "express";
import {
    listarEquipos,buscarEquipos, peq
} from "../controladores/equipoCtrl.js";
const router = Router();
// armar nuestras rutas

router.get("/equipos", listarEquipos);
router.get("/equipoxid/:id", buscarEquipos );
router.get("/partidoeq", peq);
export default router;
