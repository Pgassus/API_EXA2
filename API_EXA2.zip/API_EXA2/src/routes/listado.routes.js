import { Router } from "express";
import {
    obtenerPronosticosAcertados,listaUsuario,obtenerRecaudacion, seleccionarGanador
} from "../controladores/listadoCtrl.js";
const router = Router();
// armar nuestras rutas

router.get("/lisatdoAciertos",obtenerPronosticosAcertados);
router.get("/listaUsuario",listaUsuario);
router.get("/recaudacion",obtenerRecaudacion);
router.get("/ganador",seleccionarGanador);
export default router;
