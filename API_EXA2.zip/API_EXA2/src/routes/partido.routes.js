import { Router } from "express";
import {
  listarpartido,
  insertPartido,
  listarResultados,
  listp,
  actualizarPartido
  
} from "../controladores/partidoCtrl.js";
const router = Router();
// armar nuestras rutas

router.get("/listarpartido", listarpartido);
router.get("/listp", listp);
router.post('/partidos', insertPartido);

//router.get("/partidosactivos", obtenerPartidosActivos);
router.get("/listares", listarResultados);

// Ruta para registrar el resultado del partido y el estado
router.put('/act', actualizarPartido);

export default router;