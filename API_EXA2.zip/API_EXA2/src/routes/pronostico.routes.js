import { Router } from "express";
import {
  registrarPronostico,obtenerPartidosActivos

} from "../controladores/pronosticoCtrl.js";
const router = Router();
// armar nuestras rutas
router.post("/registarp", registrarPronostico);
router.get("/partidosactivos", obtenerPartidosActivos);//partivos activos en la pagina pronosticos



export default router;
